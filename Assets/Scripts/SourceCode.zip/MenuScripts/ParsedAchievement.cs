
public class ParsedAchievement
{
    public int id { get; set; }
    public string description { get; set; }
}
