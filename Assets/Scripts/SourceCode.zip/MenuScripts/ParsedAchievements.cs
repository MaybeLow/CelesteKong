
public class ParsedAchievements
{
    public ParsedAchievement[] achievements { get; set; }
}
